var express = require('express');
var app = express();
var mysql = require('mysql');
var bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended: true })); 

var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "1234",
  database: "weekend"
});

app.get('/',function(req,res,next)
{
res.sendfile('views/first.html');
});

app.post('/myaction', function(req, res) {

console.log('req.body');
console.log(req.body);
res.write('You sent the name "' + req.body.name+'".\n');
res.write('You sent the Email "' + req.body.email+'".\n');
res.write('You sent the City "' + req.body.city+'".\n');
res.write('You sent the Pincode "' + req.body.pincode+'".\n');

res.end()
con.query("Insert into student1 VALUES ('"+req.body.name+"','"+req.body.email+"','"+req.body.city+"','"+req.body.pincode+"')",
          function(err, result)      
{                                                      
  if (err)
     throw err;
});
});
app.listen(3100);
console.log('Example app listening at port:3100');