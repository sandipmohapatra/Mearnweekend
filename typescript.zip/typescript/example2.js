function f1() {
    var x = 10;
    if (x == 10) {
        var y = 20;
    }
    console.log("x=".concat(x, "\n y=").concat(y));
}
f1();
