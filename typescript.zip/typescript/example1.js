console.log("Welcome to typescript");
console.log("At Be-practical");
