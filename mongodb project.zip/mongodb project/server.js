var express=require('express');
var path=require('path');
var fs=require('fs');
var app=express();
var mongo=require('mongodb').MongoClient;
var ndb="mongodb://localhost:27017/weekendBatch";
var bodyParser=require('body-parser');

app.get('/',function(req,res)
{
return res.redirect('/public/index.html');
}).listen(3000);
console.log("server listening to :3000");

app.use('/public',express.static(__dirname+'/public'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:true}));

app.post('/sign_up',function(req,res)
{
var name=req.body.name;
var email=req.body.email;
var pass=req.body.password;
var phone=req.body.phone;

var data={
"name":name,
"email":email,
"pass":pass,
"phone":phone
}

mongo.connect(ndb,function(err,db)
{
if(err)throw err;
var dbo=db.db("weekendBatch");
console.log("database connected successfully");
dbo.collection("details").insertOne(data,(err,collection) =>
{
if(err) throw err;
console.log("record inserted");
console.log(collection);
});
});

console.log("data is "+JSON.stringify(data));
return res.redirect('/public/success.html');
});






